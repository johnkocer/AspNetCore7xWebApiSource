// var builder = WebApplication.CreateBuilder(args);
// builder.Services.AddCors();

// // Define CORS Policy
// builder.Services.AddCors(options =>
// {
//     options.AddPolicy("MyPolicy",
//         builder => builder.WithOrigins("https://localhost:44337"));
// });
// // Add services to the container.
// builder.Services.AddControllersWithViews();

// var app = builder.Build();

// // Configure the HTTP request pipeline.
// if (!app.Environment.IsDevelopment())
// {
//     app.UseExceptionHandler("/Home/Error");
//     // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
//     app.UseHsts();
// }


// // Configure the HTTP request pipeline.

// app.UseHttpsRedirection();
// app.UseStaticFiles();
// app.UseRouting();

// // Shows UseCors with CorsPolicyBuilder.
// app.UseCors(builder =>
// {
//     builder.AllowAnyOrigin()
//            .AllowAnyMethod()
//            .AllowAnyHeader();
// });

// // Shows UseCors with named policy.
// app.UseCors("MyPolicy");
// app.UseAuthorization();

// //app.MapControllers();
// app.MapControllerRoute(
//     name: "default",
//     pattern: "{controller=Home}/{action=Index}/{id?}");

// app.Run();

// var  MyAllowSpecificOrigins = "_myAllowSpecificOrigins";

// var builder = WebApplication.CreateBuilder(args);
// builder.Services.AddCors(options =>
// {
//     options.AddPolicy("AllowAngularOrigins",
//     builder =>
//     {
//         builder.WithOrigins(
//                             "http://localhost:44337",
//                             "https://localhost:44337"
//                             )
//                             .AllowAnyHeader()
//                             .AllowAnyMethod();
//     });
// });

// // builder.Services.AddCors(options =>
// // {
// //     options.AddPolicy(name: MyAllowSpecificOrigins,
// //                       policy  =>
// //                       {
// //                           policy.WithOrigins("http://localhost:44337",
// //                                               "https://localhost:44337")
// //                                                .AllowAnyHeader()
// //                                                .AllowAnyMethod();
// //                       });
// // });

// // services.AddResponseCaching();

// builder.Services.AddControllers();

// var app = builder.Build();
// app.UseCors("AllowAngularOrigins");
// app.UseHttpsRedirection();
// app.UseStaticFiles();
// // app.UseRouting();
// //       app.UseCors(builder => builder.WithOrigins("https://localhost:44337").SetIsOriginAllowed((host) => true));
// // //app.UseCors(MyAllowSpecificOrigins);

// app.UseAuthorization();

// app.MapControllers();

// app.Run();

//aa==

//var  MyAllowSpecificOrigins = "_myAllowSpecificOrigins";  

var builder = WebApplication.CreateBuilder(args);

//builder.Services.AddCors(options =>  
//{  
//    options.AddPolicy(name: MyAllowSpecificOrigins,  
//                      policy  =>  
//                      {  
//                          policy.WithOrigins("http://localhost:44337",  
//                                              "https://localhost:44337",
//                                              "http://127.0.0.1:5500")
//                                              .AllowAnyHeader()
//                                              .AllowAnyMethod()
//                                              .AllowAnyOrigin(); // add the allowed origins  
//                      });
//    //options.AddPolicy("AllowAllOrigins",
//    //                builder =>
//    //                {
//    //                    builder.AllowAnyOrigin();
//    //                });
//});  

builder.Services.AddCors(p => p.AddPolicy("SmartIt", build =>
    {
        build.WithOrigins("https://localhost:44337", "http://127.0.0.1:5500").AllowAnyMethod().AllowAnyHeader();
    }
));
// services.AddResponseCaching();  

builder.Services.AddControllers();

var app = builder.Build();

//app.UseCors("AllowAllOrigins");

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseCors("SmartIt");

app.MapControllers();
app.Run();